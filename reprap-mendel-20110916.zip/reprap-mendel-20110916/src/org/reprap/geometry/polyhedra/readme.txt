Holding directory for 3D geometry code in the future.

Adrian Bowyer  12 February 2008
