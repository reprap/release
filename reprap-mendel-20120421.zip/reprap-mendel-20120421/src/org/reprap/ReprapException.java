package org.reprap;

public class ReprapException extends Exception {
	static final long serialVersionUID = 0;

	public ReprapException() {
		super();
	}

	public ReprapException(String arg0) {
		super(arg0);
	}

	public ReprapException(Throwable arg0) {
		super(arg0);
	}

}
