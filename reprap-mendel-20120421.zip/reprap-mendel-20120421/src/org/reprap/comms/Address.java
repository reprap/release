//package org.reprap.comms;
//
//
///**
// * Interface that handles some of the Address
// */
//public interface Address {
//	
//	/**
//	 * @param arg address to compare with
//	 * @return true if the addresses are identical
//	 */
//	public boolean equals(Object arg);
//	
//	/**
//	 * @return binary array representation of the address
//	 */
//	public byte [] getBinary();
//
//	/**
//	 * @return ???
//	 */
//	public Address getNullAddress();
//	
//	/**
//	 * @return string representation of the adress
//	 */
//	public String toString();
//}
