//package org.reprap.comms;
//
//// TODO add support for specifying command byte as well
//
//public class IncomingContext {
//	
//	/**
//	 * 
//	 */
//	private Communicator communicator;
//	
//	/**
//	 * 
//	 */
//	private Address expectedAddress;
//
//	/**
//	 * 
//	 * @param communicator The communicator to receive messages from
//	 * @param address Address to receive messages from (null for any)
//	 */
//	public IncomingContext(Communicator communicator, Address address) {
//		expectedAddress = address;
//		this.communicator = communicator;
//	}
//
//	/**
//	 * @return communicator
//	 */
//	public Communicator getCommunicator() {
//		return communicator;
//	}
//
//	/**
//	 * @return expectedAddress
//	 */
//	public Address getExpectedAddress() {
//		return expectedAddress;
//	}
//
//}
