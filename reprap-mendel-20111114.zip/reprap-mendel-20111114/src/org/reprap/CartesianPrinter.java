package org.reprap;


/**
 *
 */
public interface CartesianPrinter extends Printer {

}
