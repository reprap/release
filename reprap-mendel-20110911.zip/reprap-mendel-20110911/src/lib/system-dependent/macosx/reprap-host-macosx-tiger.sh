#!/bin/sh

export JAVA_HOME=/usr/local/soylatte16
export PATH=$JAVA_HOME/bin:$PATH
export 
java -jar reprap.jar
